﻿namespace GPIOTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlINPUTS = new System.Windows.Forms.Panel();
            this.pnlIN4 = new System.Windows.Forms.Panel();
            this.lblIN4 = new System.Windows.Forms.Label();
            this.rbIN4 = new System.Windows.Forms.RadioButton();
            this.pnlIN3 = new System.Windows.Forms.Panel();
            this.lblIN3 = new System.Windows.Forms.Label();
            this.rbIN3 = new System.Windows.Forms.RadioButton();
            this.pnlIN2 = new System.Windows.Forms.Panel();
            this.lblIN2 = new System.Windows.Forms.Label();
            this.rbIN2 = new System.Windows.Forms.RadioButton();
            this.pnlIN1 = new System.Windows.Forms.Panel();
            this.lblIN1 = new System.Windows.Forms.Label();
            this.rbIN1 = new System.Windows.Forms.RadioButton();
            this.lblINPUTS = new System.Windows.Forms.Label();
            this.pnlOUTPUTS = new System.Windows.Forms.Panel();
            this.pnlOut1 = new System.Windows.Forms.Panel();
            this.lblOUT1 = new System.Windows.Forms.Label();
            this.btnOut1ON = new System.Windows.Forms.Button();
            this.btnOut1OFF = new System.Windows.Forms.Button();
            this.pnlOut4 = new System.Windows.Forms.Panel();
            this.lblOUT4 = new System.Windows.Forms.Label();
            this.btnOut4ON = new System.Windows.Forms.Button();
            this.btnOut4OFF = new System.Windows.Forms.Button();
            this.pnlOut2 = new System.Windows.Forms.Panel();
            this.lblOUT2 = new System.Windows.Forms.Label();
            this.btnOut2ON = new System.Windows.Forms.Button();
            this.btnOut2OFF = new System.Windows.Forms.Button();
            this.pnlOut3 = new System.Windows.Forms.Panel();
            this.lblOUT3 = new System.Windows.Forms.Label();
            this.btnOut3ON = new System.Windows.Forms.Button();
            this.btnOut3OFF = new System.Windows.Forms.Button();
            this.lblOUTPUTS = new System.Windows.Forms.Label();
            this.tmrPOLL = new System.Windows.Forms.Timer();
            this.pnlINPUTS.SuspendLayout();
            this.pnlIN4.SuspendLayout();
            this.pnlIN3.SuspendLayout();
            this.pnlIN2.SuspendLayout();
            this.pnlIN1.SuspendLayout();
            this.pnlOUTPUTS.SuspendLayout();
            this.pnlOut1.SuspendLayout();
            this.pnlOut4.SuspendLayout();
            this.pnlOut2.SuspendLayout();
            this.pnlOut3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlINPUTS
            // 
            this.pnlINPUTS.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pnlINPUTS.Controls.Add(this.pnlIN4);
            this.pnlINPUTS.Controls.Add(this.pnlIN3);
            this.pnlINPUTS.Controls.Add(this.pnlIN2);
            this.pnlINPUTS.Controls.Add(this.pnlIN1);
            this.pnlINPUTS.Controls.Add(this.lblINPUTS);
            this.pnlINPUTS.Location = new System.Drawing.Point(16, 64);
            this.pnlINPUTS.Name = "pnlINPUTS";
            this.pnlINPUTS.Size = new System.Drawing.Size(257, 141);
            // 
            // pnlIN4
            // 
            this.pnlIN4.Controls.Add(this.lblIN4);
            this.pnlIN4.Controls.Add(this.rbIN4);
            this.pnlIN4.Location = new System.Drawing.Point(193, 38);
            this.pnlIN4.Name = "pnlIN4";
            this.pnlIN4.Size = new System.Drawing.Size(58, 64);
            // 
            // lblIN4
            // 
            this.lblIN4.Location = new System.Drawing.Point(3, 6);
            this.lblIN4.Name = "lblIN4";
            this.lblIN4.Size = new System.Drawing.Size(51, 20);
            this.lblIN4.Text = "IN4";
            this.lblIN4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rbIN4
            // 
            this.rbIN4.Location = new System.Drawing.Point(19, 29);
            this.rbIN4.Name = "rbIN4";
            this.rbIN4.Size = new System.Drawing.Size(24, 20);
            this.rbIN4.TabIndex = 1;
            // 
            // pnlIN3
            // 
            this.pnlIN3.Controls.Add(this.lblIN3);
            this.pnlIN3.Controls.Add(this.rbIN3);
            this.pnlIN3.Location = new System.Drawing.Point(130, 38);
            this.pnlIN3.Name = "pnlIN3";
            this.pnlIN3.Size = new System.Drawing.Size(58, 64);
            // 
            // lblIN3
            // 
            this.lblIN3.Location = new System.Drawing.Point(3, 6);
            this.lblIN3.Name = "lblIN3";
            this.lblIN3.Size = new System.Drawing.Size(51, 20);
            this.lblIN3.Text = "IN3";
            this.lblIN3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rbIN3
            // 
            this.rbIN3.Location = new System.Drawing.Point(19, 29);
            this.rbIN3.Name = "rbIN3";
            this.rbIN3.Size = new System.Drawing.Size(24, 20);
            this.rbIN3.TabIndex = 1;
            // 
            // pnlIN2
            // 
            this.pnlIN2.Controls.Add(this.lblIN2);
            this.pnlIN2.Controls.Add(this.rbIN2);
            this.pnlIN2.Location = new System.Drawing.Point(67, 38);
            this.pnlIN2.Name = "pnlIN2";
            this.pnlIN2.Size = new System.Drawing.Size(58, 64);
            // 
            // lblIN2
            // 
            this.lblIN2.Location = new System.Drawing.Point(3, 6);
            this.lblIN2.Name = "lblIN2";
            this.lblIN2.Size = new System.Drawing.Size(51, 20);
            this.lblIN2.Text = "IN2";
            this.lblIN2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rbIN2
            // 
            this.rbIN2.Location = new System.Drawing.Point(19, 29);
            this.rbIN2.Name = "rbIN2";
            this.rbIN2.Size = new System.Drawing.Size(24, 20);
            this.rbIN2.TabIndex = 1;
            // 
            // pnlIN1
            // 
            this.pnlIN1.Controls.Add(this.lblIN1);
            this.pnlIN1.Controls.Add(this.rbIN1);
            this.pnlIN1.Location = new System.Drawing.Point(4, 38);
            this.pnlIN1.Name = "pnlIN1";
            this.pnlIN1.Size = new System.Drawing.Size(58, 64);
            // 
            // lblIN1
            // 
            this.lblIN1.Location = new System.Drawing.Point(3, 6);
            this.lblIN1.Name = "lblIN1";
            this.lblIN1.Size = new System.Drawing.Size(51, 20);
            this.lblIN1.Text = "IN1";
            this.lblIN1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rbIN1
            // 
            this.rbIN1.Location = new System.Drawing.Point(19, 29);
            this.rbIN1.Name = "rbIN1";
            this.rbIN1.Size = new System.Drawing.Size(24, 20);
            this.rbIN1.TabIndex = 1;
            // 
            // lblINPUTS
            // 
            this.lblINPUTS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblINPUTS.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular);
            this.lblINPUTS.Location = new System.Drawing.Point(-3, 3);
            this.lblINPUTS.Name = "lblINPUTS";
            this.lblINPUTS.Size = new System.Drawing.Size(247, 32);
            this.lblINPUTS.Text = "DIGITAL INPUTS";
            this.lblINPUTS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnlOUTPUTS
            // 
            this.pnlOUTPUTS.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pnlOUTPUTS.Controls.Add(this.pnlOut1);
            this.pnlOUTPUTS.Controls.Add(this.pnlOut4);
            this.pnlOUTPUTS.Controls.Add(this.pnlOut2);
            this.pnlOUTPUTS.Controls.Add(this.pnlOut3);
            this.pnlOUTPUTS.Controls.Add(this.lblOUTPUTS);
            this.pnlOUTPUTS.Location = new System.Drawing.Point(359, 64);
            this.pnlOUTPUTS.Name = "pnlOUTPUTS";
            this.pnlOUTPUTS.Size = new System.Drawing.Size(257, 141);
            // 
            // pnlOut1
            // 
            this.pnlOut1.Controls.Add(this.lblOUT1);
            this.pnlOut1.Controls.Add(this.btnOut1ON);
            this.pnlOut1.Controls.Add(this.btnOut1OFF);
            this.pnlOut1.Location = new System.Drawing.Point(3, 38);
            this.pnlOut1.Name = "pnlOut1";
            this.pnlOut1.Size = new System.Drawing.Size(58, 100);
            // 
            // lblOUT1
            // 
            this.lblOUT1.Location = new System.Drawing.Point(4, 6);
            this.lblOUT1.Name = "lblOUT1";
            this.lblOUT1.Size = new System.Drawing.Size(51, 20);
            this.lblOUT1.Text = "OUT1";
            this.lblOUT1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnOut1ON
            // 
            this.btnOut1ON.Location = new System.Drawing.Point(3, 29);
            this.btnOut1ON.Name = "btnOut1ON";
            this.btnOut1ON.Size = new System.Drawing.Size(52, 31);
            this.btnOut1ON.TabIndex = 0;
            this.btnOut1ON.Text = "ON";
            this.btnOut1ON.Click += new System.EventHandler(this.btnOut1ON_Click);
            // 
            // btnOut1OFF
            // 
            this.btnOut1OFF.Location = new System.Drawing.Point(3, 66);
            this.btnOut1OFF.Name = "btnOut1OFF";
            this.btnOut1OFF.Size = new System.Drawing.Size(52, 31);
            this.btnOut1OFF.TabIndex = 1;
            this.btnOut1OFF.Text = "OFF";
            this.btnOut1OFF.Click += new System.EventHandler(this.btnOut1OFF_Click);
            // 
            // pnlOut4
            // 
            this.pnlOut4.Controls.Add(this.lblOUT4);
            this.pnlOut4.Controls.Add(this.btnOut4ON);
            this.pnlOut4.Controls.Add(this.btnOut4OFF);
            this.pnlOut4.Location = new System.Drawing.Point(195, 38);
            this.pnlOut4.Name = "pnlOut4";
            this.pnlOut4.Size = new System.Drawing.Size(58, 100);
            // 
            // lblOUT4
            // 
            this.lblOUT4.Location = new System.Drawing.Point(4, 6);
            this.lblOUT4.Name = "lblOUT4";
            this.lblOUT4.Size = new System.Drawing.Size(51, 20);
            this.lblOUT4.Text = "OUT4";
            this.lblOUT4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnOut4ON
            // 
            this.btnOut4ON.Location = new System.Drawing.Point(3, 29);
            this.btnOut4ON.Name = "btnOut4ON";
            this.btnOut4ON.Size = new System.Drawing.Size(52, 31);
            this.btnOut4ON.TabIndex = 0;
            this.btnOut4ON.Text = "ON";
            this.btnOut4ON.Click += new System.EventHandler(this.btnOut4ON_Click);
            // 
            // btnOut4OFF
            // 
            this.btnOut4OFF.Location = new System.Drawing.Point(2, 66);
            this.btnOut4OFF.Name = "btnOut4OFF";
            this.btnOut4OFF.Size = new System.Drawing.Size(52, 31);
            this.btnOut4OFF.TabIndex = 1;
            this.btnOut4OFF.Text = "OFF";
            this.btnOut4OFF.Click += new System.EventHandler(this.btnOut4OFF_Click);
            // 
            // pnlOut2
            // 
            this.pnlOut2.Controls.Add(this.lblOUT2);
            this.pnlOut2.Controls.Add(this.btnOut2ON);
            this.pnlOut2.Controls.Add(this.btnOut2OFF);
            this.pnlOut2.Location = new System.Drawing.Point(67, 38);
            this.pnlOut2.Name = "pnlOut2";
            this.pnlOut2.Size = new System.Drawing.Size(58, 100);
            // 
            // lblOUT2
            // 
            this.lblOUT2.Location = new System.Drawing.Point(4, 6);
            this.lblOUT2.Name = "lblOUT2";
            this.lblOUT2.Size = new System.Drawing.Size(51, 20);
            this.lblOUT2.Text = "OUT2";
            this.lblOUT2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnOut2ON
            // 
            this.btnOut2ON.Location = new System.Drawing.Point(3, 29);
            this.btnOut2ON.Name = "btnOut2ON";
            this.btnOut2ON.Size = new System.Drawing.Size(52, 31);
            this.btnOut2ON.TabIndex = 0;
            this.btnOut2ON.Text = "ON";
            this.btnOut2ON.Click += new System.EventHandler(this.btnOut2ON_Click);
            // 
            // btnOut2OFF
            // 
            this.btnOut2OFF.Location = new System.Drawing.Point(3, 66);
            this.btnOut2OFF.Name = "btnOut2OFF";
            this.btnOut2OFF.Size = new System.Drawing.Size(52, 31);
            this.btnOut2OFF.TabIndex = 1;
            this.btnOut2OFF.Text = "OFF";
            this.btnOut2OFF.Click += new System.EventHandler(this.btnOut2OFF_Click);
            // 
            // pnlOut3
            // 
            this.pnlOut3.Controls.Add(this.lblOUT3);
            this.pnlOut3.Controls.Add(this.btnOut3ON);
            this.pnlOut3.Controls.Add(this.btnOut3OFF);
            this.pnlOut3.Location = new System.Drawing.Point(131, 38);
            this.pnlOut3.Name = "pnlOut3";
            this.pnlOut3.Size = new System.Drawing.Size(58, 100);
            // 
            // lblOUT3
            // 
            this.lblOUT3.Location = new System.Drawing.Point(4, 6);
            this.lblOUT3.Name = "lblOUT3";
            this.lblOUT3.Size = new System.Drawing.Size(51, 20);
            this.lblOUT3.Text = "OUT3";
            this.lblOUT3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnOut3ON
            // 
            this.btnOut3ON.Location = new System.Drawing.Point(3, 29);
            this.btnOut3ON.Name = "btnOut3ON";
            this.btnOut3ON.Size = new System.Drawing.Size(52, 31);
            this.btnOut3ON.TabIndex = 0;
            this.btnOut3ON.Text = "ON";
            this.btnOut3ON.Click += new System.EventHandler(this.btnOut3ON_Click);
            // 
            // btnOut3OFF
            // 
            this.btnOut3OFF.Location = new System.Drawing.Point(3, 66);
            this.btnOut3OFF.Name = "btnOut3OFF";
            this.btnOut3OFF.Size = new System.Drawing.Size(52, 31);
            this.btnOut3OFF.TabIndex = 1;
            this.btnOut3OFF.Text = "OFF";
            this.btnOut3OFF.Click += new System.EventHandler(this.btnOut3OFF_Click);
            // 
            // lblOUTPUTS
            // 
            this.lblOUTPUTS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOUTPUTS.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular);
            this.lblOUTPUTS.Location = new System.Drawing.Point(7, 3);
            this.lblOUTPUTS.Name = "lblOUTPUTS";
            this.lblOUTPUTS.Size = new System.Drawing.Size(243, 32);
            this.lblOUTPUTS.Text = "DIGITAL OUTPUTS";
            this.lblOUTPUTS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tmrPOLL
            // 
            this.tmrPOLL.Interval = 250;
            this.tmrPOLL.Tick += new System.EventHandler(this.tmrPOLL_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(638, 300);
            this.Controls.Add(this.pnlINPUTS);
            this.Controls.Add(this.pnlOUTPUTS);
            this.Name = "Form1";
            this.Text = "GPIO Test ";
            this.pnlINPUTS.ResumeLayout(false);
            this.pnlIN4.ResumeLayout(false);
            this.pnlIN3.ResumeLayout(false);
            this.pnlIN2.ResumeLayout(false);
            this.pnlIN1.ResumeLayout(false);
            this.pnlOUTPUTS.ResumeLayout(false);
            this.pnlOut1.ResumeLayout(false);
            this.pnlOut4.ResumeLayout(false);
            this.pnlOut2.ResumeLayout(false);
            this.pnlOut3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlINPUTS;
        private System.Windows.Forms.Panel pnlIN4;
        private System.Windows.Forms.Label lblIN4;
        private System.Windows.Forms.RadioButton rbIN4;
        private System.Windows.Forms.Panel pnlIN3;
        private System.Windows.Forms.Label lblIN3;
        private System.Windows.Forms.RadioButton rbIN3;
        private System.Windows.Forms.Panel pnlIN2;
        private System.Windows.Forms.Label lblIN2;
        private System.Windows.Forms.RadioButton rbIN2;
        private System.Windows.Forms.Panel pnlIN1;
        private System.Windows.Forms.Label lblIN1;
        private System.Windows.Forms.RadioButton rbIN1;
        private System.Windows.Forms.Label lblINPUTS;
        private System.Windows.Forms.Panel pnlOUTPUTS;
        private System.Windows.Forms.Panel pnlOut1;
        private System.Windows.Forms.Label lblOUT1;
        private System.Windows.Forms.Button btnOut1ON;
        private System.Windows.Forms.Button btnOut1OFF;
        private System.Windows.Forms.Panel pnlOut4;
        private System.Windows.Forms.Label lblOUT4;
        private System.Windows.Forms.Button btnOut4ON;
        private System.Windows.Forms.Button btnOut4OFF;
        private System.Windows.Forms.Panel pnlOut2;
        private System.Windows.Forms.Label lblOUT2;
        private System.Windows.Forms.Button btnOut2ON;
        private System.Windows.Forms.Button btnOut2OFF;
        private System.Windows.Forms.Panel pnlOut3;
        private System.Windows.Forms.Label lblOUT3;
        private System.Windows.Forms.Button btnOut3ON;
        private System.Windows.Forms.Button btnOut3OFF;
        private System.Windows.Forms.Label lblOUTPUTS;
        private System.Windows.Forms.Timer tmrPOLL;
    }
}

