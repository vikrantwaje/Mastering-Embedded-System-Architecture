namespace VUEII_test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNotificationLEDAOFF = new System.Windows.Forms.Button();
            this.btnNotificationLEDAON = new System.Windows.Forms.Button();
            this.btnNotificationLEDAFLASH = new System.Windows.Forms.Button();
            this.btnNotificationLEDBFLASH = new System.Windows.Forms.Button();
            this.btnNotificationLEDBON = new System.Windows.Forms.Button();
            this.btnNotificationLEDBOFF = new System.Windows.Forms.Button();
            this.btnNotificationLEDCOFF = new System.Windows.Forms.Button();
            this.btnNotificationLEDCON = new System.Windows.Forms.Button();
            this.btnNotificationLEDCFLASH = new System.Windows.Forms.Button();
            this.btnNotificationLEDDFLASH = new System.Windows.Forms.Button();
            this.btnNotificationLEDDON = new System.Windows.Forms.Button();
            this.btnNotificationLEDDOFF = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNotificationLEDAOFF
            // 
            this.btnNotificationLEDAOFF.Location = new System.Drawing.Point(17, 34);
            this.btnNotificationLEDAOFF.Name = "btnNotificationLEDAOFF";
            this.btnNotificationLEDAOFF.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDAOFF.TabIndex = 0;
            this.btnNotificationLEDAOFF.Text = "LEDA OFF";
            this.btnNotificationLEDAOFF.Click += new System.EventHandler(this.btnNotificationLEDAOFF_Click);
            // 
            // btnNotificationLEDAON
            // 
            this.btnNotificationLEDAON.Location = new System.Drawing.Point(17, 72);
            this.btnNotificationLEDAON.Name = "btnNotificationLEDAON";
            this.btnNotificationLEDAON.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDAON.TabIndex = 1;
            this.btnNotificationLEDAON.Text = "LEDA ON";
            this.btnNotificationLEDAON.Click += new System.EventHandler(this.btnNotificationLEDAON_Click);
            // 
            // btnNotificationLEDAFLASH
            // 
            this.btnNotificationLEDAFLASH.Location = new System.Drawing.Point(17, 110);
            this.btnNotificationLEDAFLASH.Name = "btnNotificationLEDAFLASH";
            this.btnNotificationLEDAFLASH.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDAFLASH.TabIndex = 2;
            this.btnNotificationLEDAFLASH.Text = "LEDA FLASH";
            this.btnNotificationLEDAFLASH.Click += new System.EventHandler(this.btnNotificationLEDAFLASH_Click);
            // 
            // btnNotificationLEDBFLASH
            // 
            this.btnNotificationLEDBFLASH.Location = new System.Drawing.Point(117, 110);
            this.btnNotificationLEDBFLASH.Name = "btnNotificationLEDBFLASH";
            this.btnNotificationLEDBFLASH.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDBFLASH.TabIndex = 5;
            this.btnNotificationLEDBFLASH.Text = "LEDB FLASH";
            this.btnNotificationLEDBFLASH.Click += new System.EventHandler(this.btnNotificationLEDBFLASH_Click);
            // 
            // btnNotificationLEDBON
            // 
            this.btnNotificationLEDBON.Location = new System.Drawing.Point(117, 72);
            this.btnNotificationLEDBON.Name = "btnNotificationLEDBON";
            this.btnNotificationLEDBON.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDBON.TabIndex = 4;
            this.btnNotificationLEDBON.Text = "LEDB ON";
            this.btnNotificationLEDBON.Click += new System.EventHandler(this.btnNotificationLEDBON_Click);
            // 
            // btnNotificationLEDBOFF
            // 
            this.btnNotificationLEDBOFF.Location = new System.Drawing.Point(117, 34);
            this.btnNotificationLEDBOFF.Name = "btnNotificationLEDBOFF";
            this.btnNotificationLEDBOFF.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDBOFF.TabIndex = 3;
            this.btnNotificationLEDBOFF.Text = "LEDB OFF";
            this.btnNotificationLEDBOFF.Click += new System.EventHandler(this.btnNotificationLEDBOFF_Click);
            // 
            // btnNotificationLEDCOFF
            // 
            this.btnNotificationLEDCOFF.Location = new System.Drawing.Point(217, 34);
            this.btnNotificationLEDCOFF.Name = "btnNotificationLEDCOFF";
            this.btnNotificationLEDCOFF.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDCOFF.TabIndex = 6;
            this.btnNotificationLEDCOFF.Text = "LEDC OFF";
            this.btnNotificationLEDCOFF.Click += new System.EventHandler(this.btnNotificationLEDCOFF_Click);
            // 
            // btnNotificationLEDCON
            // 
            this.btnNotificationLEDCON.Location = new System.Drawing.Point(217, 72);
            this.btnNotificationLEDCON.Name = "btnNotificationLEDCON";
            this.btnNotificationLEDCON.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDCON.TabIndex = 7;
            this.btnNotificationLEDCON.Text = "LEDC ON";
            this.btnNotificationLEDCON.Click += new System.EventHandler(this.btnNotificationLEDCON_Click);
            // 
            // btnNotificationLEDCFLASH
            // 
            this.btnNotificationLEDCFLASH.Location = new System.Drawing.Point(217, 110);
            this.btnNotificationLEDCFLASH.Name = "btnNotificationLEDCFLASH";
            this.btnNotificationLEDCFLASH.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDCFLASH.TabIndex = 8;
            this.btnNotificationLEDCFLASH.Text = "LEDC FLASH";
            this.btnNotificationLEDCFLASH.Click += new System.EventHandler(this.btnNotificationLEDCFLASH_Click);
            // 
            // btnNotificationLEDDFLASH
            // 
            this.btnNotificationLEDDFLASH.Location = new System.Drawing.Point(317, 110);
            this.btnNotificationLEDDFLASH.Name = "btnNotificationLEDDFLASH";
            this.btnNotificationLEDDFLASH.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDDFLASH.TabIndex = 11;
            this.btnNotificationLEDDFLASH.Text = "LEDD FLASH";
            this.btnNotificationLEDDFLASH.Click += new System.EventHandler(this.btnNotificationLEDDFLASH_Click);
            // 
            // btnNotificationLEDDON
            // 
            this.btnNotificationLEDDON.Location = new System.Drawing.Point(317, 72);
            this.btnNotificationLEDDON.Name = "btnNotificationLEDDON";
            this.btnNotificationLEDDON.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDDON.TabIndex = 10;
            this.btnNotificationLEDDON.Text = "LEDD ON";
            this.btnNotificationLEDDON.Click += new System.EventHandler(this.btnNotificationLEDDON_Click);
            // 
            // btnNotificationLEDDOFF
            // 
            this.btnNotificationLEDDOFF.Location = new System.Drawing.Point(317, 34);
            this.btnNotificationLEDDOFF.Name = "btnNotificationLEDDOFF";
            this.btnNotificationLEDDOFF.Size = new System.Drawing.Size(94, 20);
            this.btnNotificationLEDDOFF.TabIndex = 9;
            this.btnNotificationLEDDOFF.Text = "LEDD OFF";
            this.btnNotificationLEDDOFF.Click += new System.EventHandler(this.btnNotificationLEDDOFF_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(638, 455);
            this.Controls.Add(this.btnNotificationLEDDFLASH);
            this.Controls.Add(this.btnNotificationLEDDON);
            this.Controls.Add(this.btnNotificationLEDDOFF);
            this.Controls.Add(this.btnNotificationLEDCFLASH);
            this.Controls.Add(this.btnNotificationLEDCON);
            this.Controls.Add(this.btnNotificationLEDCOFF);
            this.Controls.Add(this.btnNotificationLEDBFLASH);
            this.Controls.Add(this.btnNotificationLEDBON);
            this.Controls.Add(this.btnNotificationLEDBOFF);
            this.Controls.Add(this.btnNotificationLEDAFLASH);
            this.Controls.Add(this.btnNotificationLEDAON);
            this.Controls.Add(this.btnNotificationLEDAOFF);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Notification LED test ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNotificationLEDAOFF;
        private System.Windows.Forms.Button btnNotificationLEDAON;
        private System.Windows.Forms.Button btnNotificationLEDAFLASH;
        private System.Windows.Forms.Button btnNotificationLEDBFLASH;
        private System.Windows.Forms.Button btnNotificationLEDBON;
        private System.Windows.Forms.Button btnNotificationLEDBOFF;
        private System.Windows.Forms.Button btnNotificationLEDCOFF;
        private System.Windows.Forms.Button btnNotificationLEDCON;
        private System.Windows.Forms.Button btnNotificationLEDCFLASH;
        private System.Windows.Forms.Button btnNotificationLEDDFLASH;
        private System.Windows.Forms.Button btnNotificationLEDDON;
        private System.Windows.Forms.Button btnNotificationLEDDOFF;
    }
}

